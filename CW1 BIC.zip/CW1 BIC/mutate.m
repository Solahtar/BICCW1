%Mutation function
%Takes the parent and adds between -0.25 and 0.25 as noise to create the
%next generation

function [child] = mutate(parent, DIM)
child = parent;
    for i = 1:DIM
            child(i) = child(i)+(-0.25 + 0.5*rand);
    end
end
